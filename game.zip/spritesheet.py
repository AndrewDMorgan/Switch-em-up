import pygame, math

pygame.init()


class Spritesheet:
    def __init__(self, image) -> None:
        self.image = pygame.image.load(image)
        self.surf = pygame.Surface((self.image.get_width(), self.image.get_height()))
        self.size = (self.image.get_width(), self.image.get_height())
        self.surf.blit(self.image, [0, 0])
    def get_images(self, scaleX, scaleY):
        images = []
        Y = self.size[1] // scaleY + 1
        X = self.size[0] // scaleX
        for i in range(math.floor((self.size[0] / scaleX) * (self.size[1] / scaleY))):
            x = (i % X) * scaleX
            y = (i // X) * scaleY
            surf = pygame.Surface((scaleX, scaleY))
            surf.blit(self.image, [-x, -y])
            surf.convert()
            surf.set_colorkey((0, 0, 0), pygame.RLEACCEL)
            images.append(surf)
        return images

