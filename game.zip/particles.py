import random, pygame, math, json
from animation import Animation

PI = math.pi

pygame.init()


def blend_rgb(col1: tuple, col2: tuple, amount: float) -> tuple:
    oa, amount = amount, 1 - amount
    return (col1[0] * amount + col2[0] * oa, col1[1] * amount + col2[1] * oa, col1[2] * amount + col2[2] * oa)


class Particle:
    def __init__(self, game, animtion, life_time: float = 100, scale_vel: tuple = (0, 0), scale: tuple = (0, 0), pos: tuple = (0, 0), inersia: tuple = (0, 0), light: bool = False, light_color: tuple = (0, 0, 0), state: str = '', rot: float = 0, rot_vel: float = 0, light_r: int = 0) -> None:
        self.game = game
        self.light = light
        self.state = state
        self.life = life_time
        self.light_color = light_color
        self.pos = pos
        self.vel = inersia
        self.rot = rot
        self.rot_vel = rot_vel
        self.scale = scale
        self.scale_vel = scale_vel
        self.animtion = animtion
        if self.light:
            self.light_r = light_r
            self.r = 0
            self.f = random.uniform(-5, 5)
            self.light_surf = pygame.Surface((50, 50))
            self.light_surf.fill((255, 255, 255))
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.95), [25, 25], 25)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.85), [25, 25], 23)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.75), [25, 25], 21)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.65), [25, 25], 19)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.55), [25, 25], 17)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.45), [25, 25], 15)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.35), [25, 25], 13)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.25), [25, 25], 11)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.15), [25, 25], 9)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.05), [25, 25], 7)
            pygame.draw.circle(self.light_surf, light_color, [25, 25], 5)
    def update(self, acelleration: tuple = (0, 0), state: str = None, rot_acell: float = 0, scale_acell: tuple = (0, 0)) -> None:
        if state != None:
            self.state = state
        self.life -= self.game.time.dt
        self.vel = (self.vel[0] + acelleration[0], self.vel[1] + acelleration[1])
        self.pos = (self.pos[0] + self.vel[0], self.pos[1] + self.vel[1])
        self.rot_vel += rot_acell
        self.rot += self.rot_vel
        self.scale_vel = (self.scale_vel[0] + scale_acell[0], self.scale_vel[1] + scale_acell[1])
        self.scale = (self.scale[0] + self.scale_vel[0], self.scale[1] + self.scale_vel[1])
        self.animtion.update(new_sate = self.state)
    def render(self) -> None:
        self.r_pos = (self.pos[0] - self.game.camera_pos[1]), self.pos[1] - self.game.camera_pos[0]
        if self.r_pos[0] > 0 and self.r_pos[0] < 1225 and self.r_pos[1] > 0 and self.r_pos[1] < 775:
            self.animtion.render(pos = self.r_pos, rotation = self.rot, scaleUp = self.scale)
            if self.light:
                self.f += 0.5 * random.uniform(0.9, 1.1) * self.game.time.dt
                if self.f > PI * 2:
                    self.f -= PI * 2
                self.r = round(self.light_r * (math.sin(self.f) / 4 + 1.25))
                self.game.map.add_light([pygame.transform.scale(self.light_surf, (self.r, self.r)), [self.r_pos[0] - (self.r / 2 - (self.animtion.sprite.get_size()[0] / 2 * self.scale[0])), self.r_pos[1] - self.r / 2 + (self.animtion.sprite.get_size()[1] / 2 * self.scale[1])]])
        else:
            self.life = 0

