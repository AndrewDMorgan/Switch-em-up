import pygame, math, json
import animation_json

pygame.init()


class Animation:
    def __init__(self, game, type: str = None, state: str = None, data = None, sprites = None) -> None:
        if type != None:
            self.states = animation_json.d[type]
        if data != None:
            self.states = data
        self.game = game
        self.state = state
        self.speed = self.states['speed']
        self.sprites = self.states['sprites']
        if data != None:
            pass
        else:
            if sprites != None:
                self.sprites = sprites
            else:
                for key in self.sprites:
                    for i in range(len(self.sprites[key])):
                        im = pygame.image.load(self.states['path'] + self.sprites[key][i])
                        size = (im.get_width(), im.get_height())
                        surf = pygame.Surface(size)
                        surf.blit(im, [0, 0])
                        surf.convert()
                        surf.set_colorkey((0, 0, 0), pygame.RLEACCEL)
                        surf = pygame.transform.scale(surf, (size[0] * self.states['scale'][key], size[1] * self.states['scale'][key]))
                        self.sprites[key][i] = surf
        self.frame = 0
    def update(self, new_sate: str = None) -> None:
        if new_sate != None:
            self.state = new_sate
        self.frame += self.speed[self.state] * self.game.time.dt
        length = len(self.sprites[self.state])
        while self.frame >= length:
            self.frame -= length
    def render(self, pos = (0, 0), rotation = 0, scaleUp = (1, 1)) -> None:
        self.sprite = self.sprites[self.state][math.floor(self.frame)]
        self.game.screen.blit(pygame.transform.scale(pygame.transform.rotate(self.sprite, rotation), (self.sprite.get_width() * scaleUp[0], self.sprite.get_height() * scaleUp[1])), pos)


def text(display, text, color, pos, size, center = False, font = 'pixel.ttf'):
    largeText = pygame.font.Font(font, size)
    textSurface = largeText.render(text, True, color)
    TextSurf, TextRect = textSurface, textSurface.get_rect()
    if center:
        TextRect.center = pos
        sprite = display.blit(TextSurf, TextRect)
    else:
        sprite = display.blit(TextSurf, pos)
    return sprite

