from spritesheet import Spritesheet
from animation import Animation
import pygame, math, random

PI = math.pi


def divide(v1: float, v2: float) -> float:
    try:
        return v1 / v2
    except ZeroDivisionError:
        return 0


def clamp(v: float, mi: float, ma: float) -> float:
    return min(max(v, mi), ma)


def get_items(l: list, indexes: list) -> list:
    out = []
    for i in indexes:
        out.append(l[i])
    return out


def blend_rgb(col1: tuple, col2: tuple, amount: float) -> tuple:
    oa, amount = amount, 1 - amount
    return (col1[0] * amount + col2[0] * oa, col1[1] * amount + col2[1] * oa, col1[2] * amount + col2[2] * oa)


lights = []

class Tile:
    def __init__(self, game, animation, pos: tuple, is_light_block: bool = False, light_color: tuple = None) -> None:
        self.pos = pos
        self.animation = animation
        self.game = game
        self.light = is_light_block
        self.r = 100
        self.f = random.uniform(-5, 5)
        if self.light:
            self.light_surf = pygame.Surface((50, 50))
            self.light_surf.fill((255, 255, 255))
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.95), [25, 25], 25)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.85), [25, 25], 23)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.75), [25, 25], 21)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.65), [25, 25], 19)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.55), [25, 25], 17)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.45), [25, 25], 15)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.35), [25, 25], 13)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.25), [25, 25], 11)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.15), [25, 25], 9)
            pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.05), [25, 25], 7)
            pygame.draw.circle(self.light_surf, light_color, [25, 25], 5)
    def render(self, cam_pos: tuple) -> None:
        global lights
        n_pos = (self.pos[0] - cam_pos[0], self.pos[1] - cam_pos[1])
        self.animation.update()
        self.animation.render(pos = n_pos)
        if self.light:
            self.f += 0.5 * random.uniform(0.9, 1.1) * self.game.time.dt
            if self.f > PI * 2:
                self.f -= PI * 2
            self.r = round(100 * (math.sin(self.f) / 4 + 1.25))
            self.size = self.r / 2 - 24
            lights.append([pygame.transform.scale(self.light_surf, (self.r, self.r)), [n_pos[0] - self.size, n_pos[1] - self.size]])


class Map:
    def __init__(self, game, map_file: str, tiles: str, scale_up: int = 1, animation_links: dict = {}, light_blocks: list = [], light_colors: list = []) -> None:
        self.scale_up = scale_up
        self.tiles = Spritesheet(tiles).get_images(24, 24)
        for i in range(len(self.tiles)):
            self.tiles[i] = pygame.transform.scale(self.tiles[i], (self.tiles[i].get_width() * self.scale_up, self.tiles[i].get_height() * self.scale_up))
        tileSizeX = self.tiles[0].get_width()
        tileSizeY = self.tiles[0].get_height()
        self.game = game
        self.light_blocks = light_blocks
        self.light_colors = light_colors
        self.map = []
        self.map_tiles = []
        self.depth = []
        unslipt = open(map_file).read().split('\n')
        Y = 0
        for x in unslipt:
            layer = []
            depth_layer = []
            tile_layer = []
            X = 0
            for y in x.split(','):
                layer2 = []
                depth = 0
                tile_layer2 = []
                for z in y.split('|'):
                    v = int(z)
                    layer2.append(v)
                    lc = None
                    if v in light_blocks:
                        lc = light_colors[light_blocks.index(v)]
                    try:
                        sv = str(v)
                        animation_links[sv]
                        tile_layer2.append(Tile(self.game, Animation(self.game, state = 'basic state', data = {
                                                                                                                  'speed': {'basic state': animation_links[sv]['speed']},
                                                                                                                  'sprites': {'basic state': get_items(self.tiles, animation_links[sv]['tiles'])}
                                                                                                              }), (X, Y), is_light_block = v in light_blocks, light_color = lc))
                    except KeyError:
                        tile_layer2.append(Tile(self.game, Animation(self.game, state = 'basic state', data = {
                                                                                                                  'speed': {'basic state': 1},
                                                                                                                  'sprites': {'basic state': [self.tiles[v]]}
                                                                                                              }), (X, Y), is_light_block = v in light_blocks, light_color = lc))
                    depth += 1
                layer.append(layer2)
                depth_layer.append(depth)
                tile_layer.append(tile_layer2)
                X += tileSizeY
            self.map.append(layer)
            self.depth.append(depth_layer)
            self.map_tiles.append(tile_layer)
            self.size = (len(self.map), len(self.map[0]))
            self.animation_links = animation_links
            Y += tileSizeX
            self.tileSizeX = tileSizeX
            self.tileSizeY = tileSizeY
    def render(self) -> None:
        global lights
        lights = []
        cam_pos = self.game.camera_pos
        startX = clamp(math.floor(cam_pos[0] / self.tileSizeX) - math.floor(600 / self.tileSizeY) - 1 , 0, self.size[0])
        startY = clamp(math.floor(cam_pos[1] / self.tileSizeX) - math.floor(375 / self.tileSizeY) - 1 , 0, self.size[1])
        endX   = clamp(math.floor(cam_pos[0] / self.tileSizeX) + math.ceil( 600 / self.tileSizeY) + 1 , 0, self.size[0])
        endY   = clamp(math.floor(cam_pos[1] / self.tileSizeX) + math.ceil( 375 / self.tileSizeY) + 11, 0, self.size[1])
        n_cam_pos = (cam_pos[0] - 600, cam_pos[1] - 375)
        for x in range(startX, endX):
            for y in range(startY, endY):
                for z in range(self.depth[x][y]):
                    self.map_tiles[x][y][z].render((n_cam_pos[1], n_cam_pos[0]))
    def render_lights(self) -> None:
        for light in lights:
            self.game.screen.blit(light[0], light[1], special_flags = pygame.BLEND_RGB_MULT)
    def add_light(self, light: list) -> None:
        global lights
        lights.append(light)

