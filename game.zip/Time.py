import time


class Time:
    def __init__(self) -> None:
        self.dt = 1
        self.start_time = 0
        self.end_time = 0
        self.fps = 1
    def start(self) -> None:
        self.start_time = time.time()
    def end(self) -> None:
        self.end_time = time.time()
        self.dt = self.end_time - self.start_time
        self.fps = 1 / self.dt

