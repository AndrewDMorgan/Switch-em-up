import pygame, json
import events_json

pygame.init()


class Events:
    def __init__(self, game) -> None:
        self.game = game
        self.sates = events_json.d
        self.keys = self.sates['keys']
        self.held = {}
        self.down = {}
        self.up = {}
        self.key_lookup = {}
        self.mouse_pos = (0, 0)
        self.mouse = {"down right": False, "up right": False, "held right": False, "down left": False, "up left": False, "held left": False}
        for key in self.keys:
            for num in self.keys[key]:
                self.held[key] = False
                self.up[key] = False
                self.down[key] = False
                self.key_lookup[num] = key
    def update(self) -> None:
        self.mouse_pos = pygame.mouse.get_pos()
        self.mouse_pos = (self.mouse_pos[0] * (1200 / self.game.res[0]), self.mouse_pos[1] * (750 / self.game.res[1]))
        for key in ["down right", "up right", "down left", "up left"]:
            self.mouse[key] = False
        for key in self.down:
            self.down[key] = False
            self.up[key] = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                self.game.running = False
                break
            elif event.type == pygame.KEYDOWN:
                try:
                    key = self.key_lookup[event.key]
                    self.down[key] = True
                    self.held[key] = True
                except KeyError:
                    pass
            elif event.type == pygame.KEYUP:
                try:
                    key = self.key_lookup[event.key]
                    self.up[key] = True
                    self.held[key] = False
                except KeyError:
                    pass
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    self.mouse['down right'] = True
                    self.mouse['held right'] = True
                elif event.button == 3:
                    self.mouse['down left'] = True
                    self.mouse['held left'] = True
            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    self.mouse['up right'] = True
                    self.mouse['held right'] = False
                elif event.button == 3:
                    self.mouse['up left'] = True
                    self.mouse['held left'] = False

