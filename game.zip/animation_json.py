d = {
    "turret-entity":
        {
            "path": "",
            "scale":
                {
                    "idle up":        2,
                    "mad up":         2,
                    "shooting up":    2,
                    "idle down":      2,
                    "mad down":       2,
                    "shooting down":  2,
                    "idle left":      2,
                    "mad left":       2,
                    "shooting left":  2,
                    "idle right":     2,
                    "mad right":      2,
                    "shooting right": 2,
                    "dead":           2
                },
            "speed":
                {
                    "idle up":        22,
                    "mad up":         22,
                    "shooting up":    22,
                    "idle down":      22,
                    "mad down":       22,
                    "shooting down":  22,
                    "idle left":      22,
                    "mad left":       22,
                    "shooting left":  22,
                    "idle right":     22,
                    "mad right":      22,
                    "shooting right": 22,
                    "dead":           3.5
                },
            "sprites":
                {
                    "idle up":
                        [
                            4
                        ],
                    "mad up":
                        [
                            0
                        ],
                    "shooting up":
                        [
                            0,
                            0,
                            0,
                            0,
                            1,
                            2,
                            3
                        ],
                    "idle down":
                        [
                            14
                        ],
                    "mad down":
                        [
                            10
                        ],
                    "shooting down":
                        [
                            10,
                            10,
                            10,
                            10,
                            11,
                            12,
                            13
                        ],
                    "idle left":
                        [
                            9
                        ],
                    "mad left":
                        [
                            5
                        ],
                    "shooting left":
                        [
                            5,
                            6,
                            7,
                            8
                        ],
                    "idle right":
                        [
                            19
                        ],
                    "mad right":
                        [
                            15
                        ],
                    "shooting right":
                        [
                            15,
                            15,
                            15,
                            15,
                            16,
                            17,
                            18
                        ],
                    "dead":
                        [
                            21, 22, 22, 21, 23, 24, 24, 23
                        ]
                }
        },
    "player":
        {
            "path": "",
            "scale":
                {
                    "idle left":     1,
                    "idle right":    1,
                    "jumping left":  1,
                    "jumping right": 1,
                    "walking left":  1,
                    "walking right": 1
                },
            "speed":
                {
                    "idle left":     5,
                    "idle right":    5,
                    "jumping left":  5,
                    "jumping right": 5,
                    "walking left":  5,
                    "walking right": 5
                },
            "sprites":
                {
                    "idle left":     
                        [
                            12,
                            13,
                            14,
                            15
                        ],
                    "idle right":    
                        [
                            8,
                            9,
                            10,
                            11
                        ],
                    "jumping left":  
                        [
                            20,
                            21,
                            22,
                            23
                        ],
                    "jumping right": 
                        [
                            16,
                            17,
                            18,
                            19
                        ],
                    "walking left":  
                        [
                            4,
                            5,
                            6,
                            7
                        ],
                    "walking right": 
                        [
                            0,
                            1,
                            2,
                            3
                        ]
                }
        }
}