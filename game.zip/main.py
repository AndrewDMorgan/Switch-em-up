from animation import Animation, text as Text
from spritesheet import Spritesheet
from particles import Particle
from events import Events
from map import Map, Tile
from sound import Sound
from Time import Time
import animation_json
import pygame, math
import random, time
import pyautogui

pygame.init()

# chanels    13, 9, 6, 0, (1 if in game), (2 if in muenu)


def Range(v: float, l: float, r: float) -> bool:
    return v >= l and v < r


def collide(box1: tuple, box2: tuple) -> bool:
    x = Range(box1[0], box2[0], box2[0] + box2[2]) or Range(box1[0] + box1[2], box2[0], box2[0] + box2[2])
    y = Range(box1[1], box2[1], box2[1] + box2[3]) or Range(box1[1] + box1[3], box2[1], box2[1] + box2[3])
    return x and y


def get_items(l: list, indexes: list) -> list:
    out = []
    for i in indexes:
        out.append(l[i])
    return out


def create_block(game, tile_pos1: tuple, z: int) -> Tile:
    X = tile_pos1[0] * 48 + 1200 - 96
    Y = tile_pos1[1] * 48
    lc = None
    v = str(z)
    if v in game.map.light_blocks:
        lc = game.map.light_colors[game.map.light_blocks.index(v)]
    try:
        sv = str(v)
        game.map.animation_links[sv]
        tile = (Tile(game, Animation(game, state = 'basic state', data = {
                                                                                                                  'speed': {'basic state': game.map.animation_links[sv]['speed']},
                                                                                                                  'sprites': {'basic state': get_items(game.map.tiles, game.map.animation_links[sv]['tiles'])}
                                                                                                              }), (X, Y), is_light_block = v in game.map.light_blocks, light_color = lc))
    except KeyError:
        tile = (Tile(game, Animation(game, state = 'basic state', data = {
                                                                                                  'speed': {'basic state': 1},
                                                                                                  'sprites': {'basic state': [game.map.tiles[z]]}
                                                                                              }), (X, Y), is_light_block = v in game.map.light_blocks, light_color = lc))
    game.map.depth[tile_pos1[1]][tile_pos1[0]] += 1
    game.map.map_tiles[tile_pos1[1]][tile_pos1[0]].append(tile)
    game.map.map[tile_pos1[1]][tile_pos1[0]].append(z)


def flood_fill(Pos, game, tiles, hit: dict = {}) -> list:
    Pos = (Pos[1], Pos[0])
    checking = [Pos]
    out = [Pos]
    while len(checking) > 0:
        nl = []
        for pos in checking:
            try:
                n_pos = (pos[0] + 1, pos[1])
                try:
                    hit[n_pos]
                except KeyError:
                    tile = game.map.map[n_pos[0]][n_pos[1]]
                    hit[n_pos] = True
                    for t in tile:
                        if t in tiles:
                            nl.append(n_pos)
                            out.append(n_pos)
            except IndexError:
                pass
            try:
                n_pos = (pos[0] - 1, pos[1])
                try:
                    hit[n_pos]
                except KeyError:
                    tile = game.map.map[n_pos[0]][n_pos[1]]
                    hit[n_pos] = True
                    for t in tile:
                        if t in tiles:
                            nl.append(n_pos)
                            out.append(n_pos)
            except IndexError:
                pass
            try:
                n_pos = (pos[0], pos[1] + 1)
                try:
                    hit[n_pos]
                except KeyError:
                    tile = game.map.map[n_pos[0]][n_pos[1]]
                    hit[n_pos] = True
                    for t in tile:
                        if t in tiles:
                            nl.append(n_pos)
                            out.append(n_pos)
            except IndexError:
                pass
            try:
                n_pos = (pos[0], pos[1] - 1)
                try:
                    hit[n_pos]
                except KeyError:
                    tile = game.map.map[n_pos[0]][n_pos[1]]
                    hit[n_pos] = True
                    for t in tile:
                        if t in tiles:
                            nl.append(n_pos)
                            out.append(n_pos)
            except IndexError:
                pass
        checking = nl
    return out


def IN(vs, ls) -> bool:
    i = False
    for v in ls:
        i = i or v in vs
    return i


def invert(t: tuple) -> tuple:
    return (t[1], t[0])


def length(v1: tuple, v2: tuple) -> float:
    return math.sqrt((v1[0] - v2[0]) ** 2 + (v1[1] - v2[1]) ** 2)


def normalize(t: tuple) -> tuple:
    mag = length(t, (0, 0))
    return (t[0] / mag, t[1] / mag)


pick_up_tiles = [5, 36, 38]
combination = {'5,36': 38, '36,5': 38}
collides = [0, 28, 29, 5, 17, 11, 20, 23, 38, 41, 27, 24, 19, 18]
collides_without_pickups = [0, 28, 29, 17, 11, 20, 23, 41, 27, 24, 19, 18]
proj_collides = [0, 28, 29, 17, 11, 20, 23, 36, 38, 41, 19, 18, 24, 27]

breaking_sounds = ['sounds/breaking1.mp3', 'sounds/breaking2.mp3', 'sounds/breaking3.mp3', 'sounds/breaking4.mp3', 'sounds/breaking5.mp3']
player_swapping = ['sounds/swapping.mp3']
block_comb =      ['sounds/block_combining.mp3']

prodje_sprite = pygame.image.load('prodje_sprite.png')

class Projectile (Particle):
    def __init__(self, game, pos, vel, parent) -> None:
        self.parent = parent
        self.game = game
        self.animation = Animation(self.game, sprites = [prodje_sprite], data = {"speed": {"base": 0}, "scale": {"base": 1}, "sprites": {"base": [prodje_sprite]}}, state = 'base')
        super().__init__(game, self.animation, life_time = 2, pos = pos, inersia = vel, light = True, light_color = (255, 150, 150), light_r = 20, state = 'base', )
        self.hit = False

        self.tile_pos = (math.floor((self.pos[0] - 613) / 48) + 5, math.floor((self.pos[1] - 360) / 48) - 5)
        try:
            tile = self.game.map.map[self.tile_pos[1]][self.tile_pos[0]]
            if IN(tile, proj_collides):
                self.life = -100
        except IndexError:
            pass
        self.r_vel = (self.vel[0], self.vel[1])
    def update(self) -> None:
        if not self.parent.alive:
            self.life = -100
        if self.life >= 0:
            self.vel = (self.vel[0] * 2.25, self.vel[1] * 2.25)
            super().update()
            self.vel = (self.vel[0] / 2.25, self.vel[1] / 2.25)
            if not self.hit:
                lengths = []
                for p in self.game.players:
                    if p.alive:
                        lengths.append(length(p.pos, self.pos))
                if len(lengths) == 0:
                    lengths = [1000000]
                min_length = min(lengths)
                if min_length < 100:
                    i = lengths.index(min_length)
                    pp = self.game.players[i].pos
                    ov = normalize((pp[1] - self.pos[0], pp[0] - self.pos[1]))
                    self.vel = (self.vel[0] * 0.95 + ov[0] * 0.05, self.vel[1] * 0.95 + ov[1] * 0.05)
            self.light_r = self.life / 1.75 * 20
            self.tile_pos = (math.floor((self.pos[0] - 613) / 48) + 5, math.floor((self.pos[1] - 360) / 48) - 5)
            try:
                tile = self.game.map.map[self.tile_pos[1]][self.tile_pos[0]]
                if IN(tile, proj_collides):
                    self.vel = (0, 0)
                    self.hit = True
            except IndexError:
                pass
            for p in self.game.players:
                if p.alive:
                    if collide([self.pos[0] - 2.5, self.pos[1] -2.5, 5, 5], [p.pos[1] - 10, p.pos[0] - 20, 20, 40]):
                        p.alive = False
        if not self.hit:
            self.r_vel = (self.vel[0], self.vel[1])
    def render(self) -> None:
        self.r_pos = (self.pos[0] - self.game.camera_pos[1]), self.pos[1] - self.game.camera_pos[0]
        pygame.draw.line(self.game.screen, (225, 75, 75), self.r_pos, [self.r_pos[0] + self.r_vel[1] * 5, self.r_pos[1] + self.r_vel[0] * 5], 2)


class Entity (Animation):
    def __init__(self, game, pos: tuple, alive: bool = True) -> None:
        super().__init__(game, 'turret-entity', 'idle up', sprites = animation_json.d['turret-entity']['sprites'])
        self.sprite_sheet = Spritesheet('turret.png').get_images(24, 24)
        self.pos = pos
        self.projes = []
        self.shot = 100
        self.mad = False
        self.normal = (0, 0)
        self.collider = None
        self.alive = alive
        self.channel = 7
    def update(self) -> None:
        if self.alive:
            if self.shot <= 6:
                self.shot += self.game.time.dt * self.states['speed']['shooting left']
            lengths = []
            for p in self.game.players:
                if p.alive:
                    lengths.append(length((p.pos[1], p.pos[0]), self.pos))
            if len(lengths) == 0:
                lengths = [1000000]
            min_length = min(lengths)
            i = lengths.index(min_length)
            if min_length < 125:
                self.mad = True
                pp = self.game.players[i].pos
                normal = normalize((self.pos[0] - pp[1], self.pos[1] - pp[0]))
                self.normal = normal
                if random.randint(0, round(2500 * self.game.time.dt)) == 0:
                    if True:
                        self.shot = 0
                        self.frame = 0
                    self.projes.append(Projectile(self.game, (self.pos[0] + 24 - normal[0] * 24, self.pos[1] + 24 - normal[1] * 24), (-normal[0], -normal[1]), self))
                    while len(self.projes) > 40:
                        del self.projes[0]
                    s = Sound('sounds/lazar.mp3', self.channel)
                    s * 0.3
                    s.play()
                    self.channel += 1
                    if self.channel > 8:
                        self.channel = 7
            else:
                self.mad = False
        projes = self.projes[:]
        i = 0
        for proj in self.projes:
            proj.update()
            if proj.life < 0:
                del projes[i]
                i -= 1
            i += 1
        self.projes = projes
        if self.alive:
            state = 'idle '
            if self.mad:
                state = 'mad '
                if self.shot < 7:
                    state = 'shooting '
            abses = [abs(self.normal[0]), abs(self.normal[1])]
            biggest = max(abses)
            i = abses.index(biggest)
            if i == 0:
                if self.normal[0] >= 0:
                    dir = 'left'
                else:
                    dir = 'right'
            else:
                if self.normal[1] >= 0:
                    dir = 'up'
                else:
                    dir = 'down'
            super().update(state + dir)
        else:
            super().update('dead')
    def render(self) -> None:
        pos = (self.pos[0] - self.game.camera_pos[1], self.pos[1] - self.game.camera_pos[0])
        if Range(pos[0], -48, 1200) and Range(pos[1], -48, 750):
            self.sprite = self.sprite_sheet[self.sprites[self.state][math.floor(self.frame)]]
            self.collider = self.game.screen.blit(pygame.transform.scale(pygame.transform.rotate(self.sprite, 0), (self.sprite.get_width() * 2, self.sprite.get_height() * 2)), pos)
        for proj in self.projes:
            proj.render()


def blend_rgb(col1: tuple, col2: tuple, amount: float) -> tuple:
    oa, amount = amount, 1 - amount
    return (col1[0] * amount + col2[0] * oa, col1[1] * amount + col2[1] * oa, col1[2] * amount + col2[2] * oa)


class Player:
    def __init__(self, game, pos: tuple = (0, 0), ability: str = '') -> None:
        self.game = game
        self.pos = pos
        self.velY = 0
        self.grounded = 0
        self.jumping = -5
        self.block_held = None
        self.block_rot = 0
        self.f = random.uniform(0, 5)
        self.dirX = 1
        self.ability = ability
        self.alive = True
        self.thought_bubble = pygame.transform.scale(pygame.image.load('info_bubble.png'), (60, 30))
        self.state = 'idle right'
        self.states = animation_json.d['player']
        self.frame = 0
        self.sprites = Spritesheet('player.png').get_images(20, 40)
        self.movement_sound_channel = 10
        self.light_surf = pygame.Surface((50, 50))
        self.light_surf.fill((255, 255, 255))
        light_color = (255, 255, 125)
        pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.95), [25, 25], 25)
        pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.85), [25, 25], 23)
        pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.75), [25, 25], 21)
        pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.65), [25, 25], 19)
        pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.55), [25, 25], 17)
        pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.45), [25, 25], 15)
        pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.35), [25, 25], 13)
        pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.25), [25, 25], 11)
        pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.15), [25, 25], 9)
        pygame.draw.circle(self.light_surf, blend_rgb(light_color, (255, 255, 255), 0.05), [25, 25], 7)
        pygame.draw.circle(self.light_surf, light_color, [25, 25], 5)
        self.F = 0

        self.phase_channel = 0
        self.phase_channels = [0, 1]
        self.phasing = False
    def update_without_move(self) -> None:
        self.velY += 5.5
        self.grounded -= self.game.time.dt
        self.jumping -= self.game.time.dt
        if self.alive:
            if self.ability == 'mario' and self.velY > 240:
                for ent in self.game.entities:
                    if collide([self.pos[1], self.pos[0], 20, 40], [ent.pos[0] + 6, ent.pos[1] + 6, 36, 36]):
                        self.velY = -275
                        self.grounded = 0.25
                        self.jumping = 0.25
                        self.jumping = False
                        sound = Sound('sounds/crashing_mobs.mp3', channel = 4)
                        sound * 1.25
                        sound.play()
                        break
            elif self.ability == 'kirby' and self.velY > 240:
                for ent in self.game.entities:
                    if ent.alive and collide([self.pos[1], self.pos[0], 20, 40], [ent.pos[0] + 6, ent.pos[1] + 6, 36, 36]):
                        ent.alive = False
                        self.velY = -200
                        sound = Sound('sounds/eating_mob.mp3', channel = 4)
                        sound * 1.25
                        sound.play()
                        break
        if self.move((self.pos[0] + self.velY * self.game.time.dt, self.pos[1])):
            if self.velY >= 0:
                self.grounded = 0.25
                self.jumping = 0.25
                if self.jumping:
                    self.jumping = False
                self.velY = 0
    def update(self) -> None:
        if self.alive:
            self.phasing = False
            tiles = self.game.map.map[math.floor((self.pos[0] - 384 + 40) / 48 - 5)][math.floor((self.pos[1] - 605.5) / 48 + 5)]
            for t in tiles:
                self.phasing = self.phasing or t == 41
            if self.phasing and self.ability == 'phase':
                if math.floor(self.frame) in [0, 2]:
                    self.phase_channel += 1
                    if self.phase_channel >= 2:
                        self.phase_channel = 0
                    s = Sound('sounds/phasing.mp3', channel = self.phase_channels[self.phase_channel])
                    s * 0.25
                    s.play()
            speed = 200 * self.game.time.dt
            self.state = 'idle ' + self.state.split(' ')[1]
            if self.game.events.held['left']:
                self.dirX = -1
                n_pos = (self.pos[0], self.pos[1] - speed)
                if not self.move(n_pos):
                    self.state = 'walking left'
                    if random.randint(0, round(700 * self.game.time.dt)):
                        self.movement_sound_channel += 1
                        if self.movement_sound_channel > 12:
                            self.movement_sound_channel = 10
                        s = Sound(['sounds/moving1.mp3', 'sounds/moving2.mp3'][random.randint(0, 1)], channel = 3)
                        s * 1.25
                        s.play()
            if self.game.events.held['right']:
                self.dirX = 1
                n_pos = (self.pos[0], self.pos[1] + speed)
                if not self.move(n_pos):
                    self.state = 'walking right'
                    if random.randint(0, round(200 * self.game.time.dt)):
                        self.movement_sound_channel += 1
                        if self.movement_sound_channel > 12:
                            self.movement_sound_channel = 10
                        s = Sound(['sounds/moving1.mp3', 'sounds/moving2.mp3'][random.randint(0, 1)], channel = 3)
                        #s * 1.25
                        s.play()
            if self.game.events.held['up'] and not self.jumping > 0 and self.grounded >= 0:
                self.velY = -245
                self.state = 'jumping ' + self.state.split(' ')[1]
                s = Sound('sounds/jumping.mp3', channel = 3)
                s * 0.5
                s.play()
            if Range(length((self.game.events.mouse_pos[0] - 600, self.game.events.mouse_pos[1] - 375), (0, 0)), 48, 240):
                if self.game.events.mouse['down right']:
                    if self.block_held == None:
                        n_pos = (self.game.camera_pos[1] + ((self.game.events.mouse_pos[0] - 600)), self.game.camera_pos[0] + ((self.game.events.mouse_pos[1] - 375)))
                        tile_pos = (math.floor((n_pos[0] - 605.5 - 34) / 48) - 5, math.floor((n_pos[1] - 369) / 48) + 3)
                        self.grounded = -1
                        try:
                            con = False
                            i = 0
                            l = self.game.map.depth[tile_pos[1]][tile_pos[0]] - 1
                            for t in self.game.map.map[tile_pos[1]][tile_pos[0]]:
                                if t in pick_up_tiles and i == l:
                                    con = True
                                    break
                                i += 1
                            con_for_group1 = False
                            con_for_group2 = False
                            con_for_group3 = False
                            con_for_group4 = False
                            if IN(self.game.map.map[tile_pos[1] - 1][tile_pos[0]], collides) or IN(self.game.map.map[tile_pos[1] + 1][tile_pos[0]], collides) or IN(self.game.map.map[tile_pos[1]][tile_pos[0] - 1], collides) or IN(self.game.map.map[tile_pos[1]][tile_pos[0] + 1], collides):
                                if IN(self.game.map.map[tile_pos[1] - 1][tile_pos[0]], pick_up_tiles):
                                    group = flood_fill((tile_pos[0], tile_pos[1] - 1), self.game, pick_up_tiles, hit = {invert(tile_pos): True})
                                    connections = []
                                    for P in group:
                                        p = (P[1], P[0])
                                        if IN(self.game.map.map[p[1] - 1][p[0]], collides_without_pickups) or IN(self.game.map.map[p[1] + 1][p[0]], collides_without_pickups) or IN(self.game.map.map[p[1]][p[0] - 1], collides_without_pickups) or IN(self.game.map.map[p[1]][p[0] + 1], collides_without_pickups):
                                            connections.append(p)
                                    con_for_group1 = len(connections) == 0
                                if IN(self.game.map.map[tile_pos[1] + 1][tile_pos[0]], pick_up_tiles):
                                    group = flood_fill((tile_pos[0], tile_pos[1] + 1), self.game, pick_up_tiles, hit = {invert(tile_pos): True})
                                    connections = []
                                    for P in group:
                                        p = (P[1], P[0])
                                        if IN(self.game.map.map[p[1] - 1][p[0]], collides_without_pickups) or IN(self.game.map.map[p[1] + 1][p[0]], collides_without_pickups) or IN(self.game.map.map[p[1]][p[0] - 1], collides_without_pickups) or IN(self.game.map.map[p[1]][p[0] + 1], collides_without_pickups):
                                            connections.append(p)
                                    con_for_group2 = len(connections) == 0
                                if IN(self.game.map.map[tile_pos[1]][tile_pos[0] - 1], pick_up_tiles):
                                    group = flood_fill((tile_pos[0] - 1, tile_pos[1]), self.game, pick_up_tiles, hit = {invert(tile_pos): True})
                                    connections = []
                                    for P in group:
                                        p = (P[1], P[0])
                                        if IN(self.game.map.map[p[1] - 1][p[0]], collides_without_pickups) or IN(self.game.map.map[p[1] + 1][p[0]], collides_without_pickups) or IN(self.game.map.map[p[1]][p[0] - 1], collides_without_pickups) or IN(self.game.map.map[p[1]][p[0] + 1], collides_without_pickups):
                                            connections.append(p)
                                    con_for_group3 = len(connections) == 0
                                if IN(self.game.map.map[tile_pos[1]][tile_pos[0] + 1], pick_up_tiles):
                                    group = flood_fill((tile_pos[0] + 1, tile_pos[1]), self.game, pick_up_tiles, hit = {invert(tile_pos): True})
                                    connections = []
                                    for P in group:
                                        p = (P[1], P[0])
                                        if IN(self.game.map.map[p[1] - 1][p[0]], collides_without_pickups) or IN(self.game.map.map[p[1] + 1][p[0]], collides_without_pickups) or IN(self.game.map.map[p[1]][p[0] - 1], collides_without_pickups) or IN(self.game.map.map[p[1]][p[0] + 1], collides_without_pickups):
                                            connections.append(p)
                                    con_for_group4 = len(connections) == 0
                                con_for_group = not (con_for_group1 or con_for_group2 or con_for_group3 or con_for_group4)
                                """
                                group = flood_fill(tile_pos, self.game, pick_up_tiles)
                                connections = []
                                for P in group:
                                    p = (P[1], P[0])
                                    if IN(self.game.map.map[p[1] - 1][p[0]], collides_without_pickups) or IN(self.game.map.map[p[1] + 1][p[0]], collides_without_pickups) or IN(self.game.map.map[p[1]][p[0] - 1], collides_without_pickups) or IN(self.game.map.map[p[1]][p[0] + 1], collides_without_pickups):
                                        connections.append(p)
                                con_for_group = len(connections) > 1
                                """
                            else:
                                con_for_group = True
                            if con and con_for_group:
                                self.game.map.depth[tile_pos[1]][tile_pos[0]] -= 1
                                self.block_held = self.game.map.map[tile_pos[1]][tile_pos[0]][len(self.game.map.map[tile_pos[1]][tile_pos[0]]) - 1]
                                del self.game.map.map_tiles[tile_pos[1]][tile_pos[0]][len(self.game.map.map_tiles[tile_pos[1]][tile_pos[0]]) - 1]
                                del self.game.map.map[tile_pos[1]][tile_pos[0]][len(self.game.map.map[tile_pos[1]][tile_pos[0]]) - 1]
                                s = Sound(breaking_sounds[random.randint(0, 4)], channel = 3)
                                s * 0.5
                                s.play()
                        except IndexError:
                            pass
                    else:
                        self.grounded = -1
                        n_pos = (self.game.camera_pos[1] + ((self.game.events.mouse_pos[0] - 600)), self.game.camera_pos[0] + ((self.game.events.mouse_pos[1] - 375)))
                        tile_pos = (math.floor((n_pos[0] - 605.5 - 10 - 24) / 48) - 5, math.floor((n_pos[1] - 384 + 20 - 5) / 48) + 3)
                        try:
                            con = False
                            i = 0
                            l = len(self.game.map.map[tile_pos[1]][tile_pos[0]]) - 1
                            for t in self.game.map.map[tile_pos[1]][tile_pos[0]]:
                                if t in pick_up_tiles and i == l:
                                    con = True
                                    break
                                i += 1
                            on_ground = False
                            for T in [self.game.map.map[tile_pos[1] + 1][tile_pos[0]], self.game.map.map[tile_pos[1] - 1][tile_pos[0]], self.game.map.map[tile_pos[1]][tile_pos[0] + 1], self.game.map.map[tile_pos[1]][tile_pos[0] - 1]]:
                                for t in T:
                                    on_ground = on_ground or t in collides
                            if con:
                                create_block(self.game, tile_pos, self.block_held)
                                self.game.map.depth[tile_pos[1]][tile_pos[0]] -= 1
                                self.block_held = self.game.map.map[tile_pos[1]][tile_pos[0]][len(self.game.map.map_tiles[tile_pos[1]][tile_pos[0]]) - 2]
                                del self.game.map.map_tiles[tile_pos[1]][tile_pos[0]][len(self.game.map.map_tiles[tile_pos[1]][tile_pos[0]]) - 2]
                                del self.game.map.map[tile_pos[1]][tile_pos[0]][len(self.game.map.map[tile_pos[1]][tile_pos[0]]) - 2]
                                #s = Sound(swapping[0], channel = 3)
                                #s * 0.5
                                #s.play()
                        except IndexError:
                            pass
                if self.game.events.mouse['down left']:
                    n_pos = (self.game.camera_pos[1] + ((self.game.events.mouse_pos[0] - 600)), self.game.camera_pos[0] + ((self.game.events.mouse_pos[1] - 375)))
                    tile_pos = (math.floor((n_pos[0] - 605.5 - 10 - 24) / 48) - 5, math.floor((n_pos[1] - 384 + 20 - 5) / 48) + 3)
                    if self.block_held != None:
                        try:
                            con = False
                            i = 0
                            tile = -1
                            l = len(self.game.map.map[tile_pos[1]][tile_pos[0]]) - 1
                            for t in self.game.map.map[tile_pos[1]][tile_pos[0]]:
                                if t in pick_up_tiles and i == l:
                                    con = True
                                    tile = t
                                    break
                                i += 1
                            on_ground = False
                            for T in [self.game.map.map[tile_pos[1] + 1][tile_pos[0]], self.game.map.map[tile_pos[1] - 1][tile_pos[0]], self.game.map.map[tile_pos[1]][tile_pos[0] + 1], self.game.map.map[tile_pos[1]][tile_pos[0] - 1]]:
                                for t in T:
                                    on_ground = on_ground or t in collides or t in pick_up_tiles
                            if con:
                                try:
                                    block_on_ground = tile
                                    n_block = combination[str(self.block_held) + ',' + str(block_on_ground)]
                                    create_block(self.game, tile_pos, n_block)
                                    self.game.map.depth[tile_pos[1]][tile_pos[0]] -= 1
                                    del self.game.map.map_tiles[tile_pos[1]][tile_pos[0]][len(self.game.map.map_tiles[tile_pos[1]][tile_pos[0]]) - 2]
                                    del self.game.map.map[tile_pos[1]][tile_pos[0]][len(self.game.map.map[tile_pos[1]][tile_pos[0]]) - 2]
                                    self.block_held = None
                                    s = Sound(block_comb[0], channel = 3)
                                    s * 0.5
                                    s.play()
                                except KeyError:
                                    pass
                            elif not con and on_ground and not IN(self.game.map.map[tile_pos[1]][tile_pos[0]], collides):
                                create_block(self.game, tile_pos, self.block_held)
                                self.block_held = None
                        except IndexError:
                            pass
            if self.game.events.down['e']:
                tile_pos = (math.floor((self.pos[1] - 10 - 605.5) / 48 + 5), math.floor((self.pos[0] - 384 + 20) / 48 - 5))
                if IN(self.game.map.map[tile_pos[1]][tile_pos[0]], [40]):
                    self.game.level_end = time.time()
                    self.game.won = True
                    self.game.in_game_sound.stop(500)
                    self.game.in_menu_sound.play()
                    s = Sound('sounds/win.mp3', channel = 3)
                    s * 0.5
                    s.play()
                    if self.game.menu_renderer.level_select_renderer.selected_level not in completed_levels:
                        completed_levels.append(self.game.menu_renderer.level_select_renderer.selected_level)
                        collected_stars.append(self.game.collected_stars)
                        completion_times.append(round(self.game.level_end - self.game.level_start))
                        scores.append(round(max(self.game.collected_stars * 50 + 50 - round(self.game.level_end - self.game.level_start) / 7, 0)))
                    else:
                        i = completed_levels.index(self.game.menu_renderer.level_select_renderer.selected_level)
                        score = round(max(self.game.collected_stars * 50 + 50 - round(self.game.level_end - self.game.level_start) / 7, 0))
                        if score > scores[i]:
                            scores[i] = score
                        if collected_stars[i] < self.game.collected_stars:
                            collected_stars[i] = self.game.collected_stars
                        if round(self.game.level_end - self.game.level_start) < completion_times[i]:
                            completion_times[i] = round(self.game.level_end - self.game.level_start)
    def move(self, n_pos: tuple) -> bool:
        tile_pos1 = (math.floor((n_pos[1] - 605.5 - 20) / 48 + 5), math.floor((n_pos[0] - 384 + 40) / 48 - 5))
        tile_pos2 = (math.floor((n_pos[1] - 605.5) / 48 + 5), math.floor((n_pos[0] - 384 + 40) / 48 - 5))
        tile_pos3 = (math.floor((n_pos[1] - 605.5 - 20) / 48 + 5), math.floor((n_pos[0] - 384) / 48 - 5))
        tile_pos4 = (math.floor((n_pos[1] - 605.5) / 48 + 5), math.floor((n_pos[0] - 384) / 48 - 5))
        hit_blocks = []
        try:
            if not (tile_pos1[0] < 0 or tile_pos2[0] < 0 or tile_pos2[0] < 0 or tile_pos3[0] < 0 or tile_pos1[1] < 0 or tile_pos2[1] < 0 or tile_pos2[1] < 0 or tile_pos3[1] < 0):
                hits = [self.game.map.map[tile_pos1[1]][tile_pos1[0]], self.game.map.map[tile_pos2[1]][tile_pos2[0]], self.game.map.map[tile_pos3[1]][tile_pos3[0]], self.game.map.map[tile_pos4[1]][tile_pos4[0]]]
                hit = False
                for h in hits:
                    for H in h:
                        collideable = H in collides
                        hit = hit or collideable
                        if collideable and H not in hit_blocks:
                            hit_blocks.append(H)
            else:
                hit = False
        except IndexError:
            hit = False
        if hit:
            if len(hit_blocks) == 1 and self.ability == 'phase' and hit_blocks[0] == 41:
                hit = False
        for player in self.game.players:
            if not player is self:
                box1 = [player.pos[1], player.pos[0], 20, 40]
                hit = collide([n_pos[1], n_pos[0], 20, 40], box1) or hit
        if not hit:
            self.pos = n_pos
        return hit
    def render(self) -> None:
        if not self.alive:
            self.state = 'idle ' + self.state.split(' ')[1]
        self.frame += self.states['speed'][self.state] * self.game.time.dt
        if self.frame >= 4:
            self.frame = 0
        sprite = self.sprites[self.states['sprites'][self.state][math.floor(self.frame)]]
        n_pos = math.floor(self.pos[1] - self.game.camera_pos[1]) - 10, math.floor(self.pos[0] - self.game.camera_pos[0]) - 20
        self.F += self.game.time.dt * 2
        if self.F > math.pi * 2:
            self.F -= math.pi * 2
        s = round((math.sin(self.F) / 2 + 0.5) * 20 + 15)
        if self.state.split(' ')[1] == 'right':
            self.game.map.add_light([pygame.transform.scale(self.light_surf, (s, s)), (n_pos[0] - s // 2 + 20, n_pos[1] - s // 2 + 22)])
        else:
            self.game.map.add_light([pygame.transform.scale(self.light_surf, (s, s)), (n_pos[0] - s // 2 + 5, n_pos[1] - s // 2 + 22)])
        try:
            tile_pos = (math.floor((self.pos[1] - 10 - 605.5) / 48 + 5), math.floor((self.pos[0] - 384 + 20) / 48 - 5))
            if IN(self.game.map.map[tile_pos[1]][tile_pos[0]], [40]) and self.alive:
                self.game.screen.blit(self.thought_bubble, [n_pos[0] + 10 - 30, n_pos[1] - 35])
                Text(self.game.screen, 'Press E', (75, 75, 90), (n_pos[0] + 10, n_pos[1] - 20), 20, True)
        except IndexError:
            pass
        self.f += self.game.time.dt * 2.25
        if self.f > math.pi * 2:
            self.f -= math.pi * 2
        self.block_rot = (math.sin(self.f) / 2 + 0.5) * 45
        #pygame.draw.rect(self.game.screen, (125, 125, 125), [n_pos[0], n_pos[1], 20, 40])
        self.game.screen.blit(sprite, n_pos)
        if self.block_held != None:
            bt = pygame.transform.rotate(pygame.transform.scale(self.game.map.tiles[self.block_held], (24, 24)), self.block_rot + 45)
            if self.dirX == -1:
                self.game.screen.blit(bt, [self.pos[1] - self.game.camera_pos[1] -29 - self.block_rot / 9, self.pos[0] - self.game.camera_pos[0] - 25 - self.block_rot / 6])
            else:
                self.game.screen.blit(bt, [self.pos[1] - self.game.camera_pos[1] + 2, self.pos[0] - self.game.camera_pos[0] - 27 - self.block_rot / 8])


class Star:
    def __init__(self, game, pos: tuple) -> None:
        self.game = game
        self.pos = pos
        self.collected = 0
        self.f = 0
    def update(self) -> None:
        if not self.collected:
            for player in self.game.players:
                if player.alive:
                    if collide([self.pos[0], self.pos[1], 30, 26], [player.pos[0] - 10, player.pos[1] - 20, 20, 40]):
                        self.game.collected_stars += 1
                        self.collected = True
                        s = Sound('sounds/star_pickup.mp3', channel = 6)
                        s * 0.2
                        s.play()
                        break
    def render(self) -> None:
        self.f += self.game.time.dt * 2.25
        if self.f >= 2:
            self.f = 0
        n_pos = (self.pos[1] - self.game.camera_pos[1], self.pos[0] - self.game.camera_pos[0])
        sprite = self.game.stars[math.floor(self.f + self.collected * 2)]
        self.game.screen.blit(pygame.transform.scale(sprite, (30, 26)), [n_pos[0], n_pos[1]])


fade = pygame.Surface((1200, 750))
fade.fill((125, 125, 135))
pygame.draw.rect(fade, (100, 100, 113), [600 - 129 // 2, 25, 140, 129])

selection = pygame.Surface((140, 26))  # 25.8 not 26
selection.fill((175, 175, 175))

full_screen = pyautogui.size()
resTs = [str(full_screen[0]) + ' x ' + str(full_screen[1]), '1550 x 925', '1200 x 750', '900 x 530', '600 x 375']
reses = [[full_screen[0], full_screen[1]], [1550, 925], [1200, 750], [900, 530], [600, 375]]

class Menu:
    def __init__(self, game) -> None:
        self.game = game
        self.screen = self.game.screen
        self.buttons = [pygame.image.load('button_up.png'), pygame.image.load('button_down.png')]
        self.QUIT = 0
        self.PLAY = 0
        self.SETTINGS = 0
        self.in_settings = False

        self.level_select_renderer = LevelSelectionScreen(self.game, self.buttons)
        self.selecting = False
    def render(self) -> None:
        if self.selecting and not self.in_settings:
            self.level_select_renderer.render()
        else:
            mouse_pos = self.game.events.mouse_pos
            if self.game.events.down['esc']:
                if self.in_settings:
                    for key in self.game.events.mouse:
                        self.game.events.mouse[key] = False
                self.in_settings = False
                self.selecting = False
            if self.game.events.mouse['down right']:
                if self.in_settings:
                    if Range(mouse_pos[0], 600 - 129 // 2, 600 - 129 // 2 + 113) and Range(mouse_pos[1], 25, 165):
                        i = math.floor(max(min((mouse_pos[1] - 25) / 25.8, 4), 0))
                        res = reses[i]
                        if i != 0:
                            self.game.Rscreen = pygame.display.set_mode(res)
                        else:
                            self.game.Rscreen = pygame.display.set_mode(res, pygame.FULLSCREEN)
                        for key in self.game.events.mouse:
                            self.game.events.mouse[key] = False
                        self.game.res = (res[0], res[1])
                        sound = Sound('sounds/button_clicked.mp3', channel = 4)
                        sound * 0.5
                        sound.play()
                else:
                    if Range(mouse_pos[0], 100, 100 + 40 * 6) and Range(mouse_pos[1], 200, 200 + 15 * 6):
                        self.QUIT = 1
                        sound = Sound('sounds/button_clicked.mp3', channel = 4)
                        sound * 0.5
                        sound.play()
                    if Range(mouse_pos[0], 1100 - 40 * 6, 1100) and Range(mouse_pos[1], 200, 200 + 15 * 6):
                        self.PLAY = 1
                        sound = Sound('sounds/button_clicked.mp3', channel = 4)
                        sound * 0.5
                        sound.play()
                    if Range(mouse_pos[0], 600 - 20 * 6, 600 + 20 * 6) and Range(mouse_pos[1], 500, 500 + 15 * 6):
                        self.SETTINGS = 1
                        sound = Sound('sounds/button_clicked.mp3', channel = 4)
                        sound * 0.5
                        sound.play()
            if self.game.events.mouse['up right']:
                if self.QUIT:
                    self.QUIT = 0
                    self.game.running = False
                if self.SETTINGS:
                    self.SETTINGS = 0
                    self.in_settings = True
                if self.PLAY:
                    self.selecting = True
                    self.level_select_renderer.selected_level = 0
                    self.PLAY = 0
            self.screen.blit(pygame.transform.scale(self.buttons[self.QUIT], (40 * 6, 15 * 6)), [100, 200])
            self.screen.blit(pygame.transform.scale(self.buttons[self.PLAY], (40 * 6, 15 * 6)), [1100 - 40 * 6, 200])
            self.screen.blit(pygame.transform.scale(self.buttons[self.SETTINGS], (40 * 6, 15 * 6)), [600 - 20 * 6, 500])
            Text(self.screen, 'Quit', (75, 75, 90), (100 + 20 * 6, 200 + 15 * 6 / 2.75 + 10 * self.QUIT), 60, True)
            Text(self.screen, 'Play', (75, 75, 90), (1100 - 20 * 6, 200 + 15 * 6 / 2.75 + 10 * self.PLAY), 60, True)
            Text(self.screen, 'Settings', (75, 75, 90), (600, 500 + 15 * 6 / 2.75 + 10 * self.SETTINGS), 60, True)
            if self.in_settings:
                self.screen.blit(fade, [0, 0], special_flags = pygame.BLEND_RGB_MULT)
                Text(self.screen, 'Composer + Sound Designer: Manhsterz  (manhsterz@gmail.com)', (200, 200, 205), (10, 700), 30)
                Text(self.screen, 'Developer + Artist: Andrew  (AndrewDaGamer741@gmail.com)', (200, 200, 205), (10, 725), 30)
                self.screen.blit(selection, [600 - 129 // 2, 25 + reses.index([self.game.res[0], self.game.res[1]]) * 25.8])
                i = 0
                for res in reses:
                    Text(self.screen, resTs[i], (200, 200, 205), (600 - 129 // 2, 30 + i * 25), 35)
                    i += 1
            else:
                Text(self.screen, 'Composer + Sound Designer: Manhsterz  (manhsterz@gmail.com)', (75, 75, 90), (10, 700), 30)
                Text(self.screen, 'Developer + Artist: Andrew  (AndrewDaGamer741@gmail.com)', (75, 75, 90), (10, 725), 30)


fade2_surf = pygame.Surface((1200, 750))
fade2_surf.fill((125, 125, 135))

class WonScreenRenderer:
    def __init__(self, game) -> None:
        self.game = game
        self.MENU = 0
        self.RESTART = 0
        self.buttons = self.game.menu_renderer.buttons
        self.screen = self.game.screen
        self.f = 0
    def render(self) -> None:
        global level_players, level_maps, level_stars, level_mobs, level_info
        self.f += self.game.time.dt * 2.25
        if self.f >= 2:
            self.f = 0
        self.screen.blit(fade2_surf, [0, 0], special_flags = pygame.BLEND_RGB_MULT)
        Text(self.screen, 'Level Completed', (175, 175, 182.5), (600, 175), 120, True)
        self.screen.blit(pygame.transform.scale(self.buttons[self.MENU]   , (40 * 6, 15 * 6)), [175, 350])
        self.screen.blit(pygame.transform.scale(self.buttons[self.RESTART], (40 * 6, 15 * 6)), [775, 350])
        Text(self.screen, 'Menu', (75, 75, 90),    (295, 350 + 15 * 6 / 2.75 + 10 * self.MENU   ), 60, True)
        Text(self.screen, 'Restart', (75, 75, 90), (895, 350 + 15 * 6 / 2.75 + 10 * self.RESTART), 60, True)
        e = round(self.game.level_end - self.game.level_start)
        score = round(max(self.game.collected_stars * 50 + 50 - e / 7, 0))
        Text(self.screen, 'Time: ' + str(e), (175, 175, 182.5), (400, 260), 60, True)
        Text(self.screen, 'Score: ' + str(score), (175, 175, 182.5), (800, 260), 60, True)
        for x in range(3):
            if x < self.game.collected_stars:
                self.game.screen.blit(pygame.transform.scale(self.game.stars[math.floor(self.f)], (30, 26)), [565 + x * 35, 260 - 13])
            else:
                self.game.screen.blit(pygame.transform.scale(self.game.stars[math.floor(self.f) + 2], (30, 26)), [565 + x * 35, 260 - 13])
        mouse_pos = self.game.events.mouse_pos
        if self.game.events.mouse['down right']:
            if Range(mouse_pos[0], 175, 175 + 240) and Range(mouse_pos[1], 350, 350 + 15 * 6):
                self.MENU = 1
                sound = Sound('sounds/button_clicked.mp3', channel = 4)
                sound * 0.5
                sound.play()
            if Range(mouse_pos[0], 775, 775 + 240) and Range(mouse_pos[1], 350, 350 + 15 * 6):
                self.RESTART = 1
                sound = Sound('sounds/button_clicked.mp3', channel = 4)
                sound * 0.5
                sound.play()
        if self.game.events.mouse['up right']:
            if self.MENU:
                reset_levels()
                self.MENU = 0
                self.game.current_player = 0
                self.game.won = False
                self.game.in_menu = True
                self.game.collected_stars = 0
            if self.RESTART:
                self.RESTART = 0
                reset_levels()
                self.game.players = level_players[self.game.menu_renderer.level_select_renderer.selected_level]
                self.game.Stars = level_stars[self.game.menu_renderer.level_select_renderer.selected_level]
                self.game.map = level_maps[self.game.menu_renderer.level_select_renderer.selected_level]
                self.game.entities = level_mobs[self.game.menu_renderer.level_select_renderer.selected_level]
                self.game.players = level_players[self.game.menu_renderer.level_select_renderer.selected_level]
                self.game.info_bubbles = level_info[self.game.menu_renderer.level_select_renderer.selected_level]
                self.game.current_player = 0
                self.game.won = False
                self.game.in_menu_sound.stop(500)
                self.game.in_game_sound.play()
                self.game.collected_stars = 0
                self.game.level_start = time.time()


class RestartScreenRenderer:
    def __init__(self, game) -> None:
        self.game = game
        self.MENU = 0
        self.RESTART = 0
        self.buttons = self.game.menu_renderer.buttons
        self.screen = self.game.screen
    def render(self) -> None:
        global level_players, level_maps, level_stars, level_mobs, level_info
        self.screen.blit(fade2_surf, [0, 0], special_flags = pygame.BLEND_RGB_MULT)
        Text(self.screen, 'Game Over', (175, 175, 182.5), (600, 175), 120, True)
        self.screen.blit(pygame.transform.scale(self.buttons[self.MENU]   , (40 * 6, 15 * 6)), [175, 350])
        self.screen.blit(pygame.transform.scale(self.buttons[self.RESTART], (40 * 6, 15 * 6)), [775, 350])
        Text(self.screen, 'Menu', (75, 75, 90),    (295, 350 + 15 * 6 / 2.75 + 10 * self.MENU   ), 60, True)
        Text(self.screen, 'Restart', (75, 75, 90), (895, 350 + 15 * 6 / 2.75 + 10 * self.RESTART), 60, True)
        mouse_pos = self.game.events.mouse_pos
        if self.game.events.mouse['down right']:
            if Range(mouse_pos[0], 175, 175 + 240) and Range(mouse_pos[1], 350, 350 + 15 * 6):
                self.MENU = 1
                sound = Sound('sounds/button_clicked.mp3', channel = 4)
                sound * 0.5
                sound.play()
            if Range(mouse_pos[0], 775, 775 + 240) and Range(mouse_pos[1], 350, 350 + 15 * 6):
                self.RESTART = 1
                sound = Sound('sounds/button_clicked.mp3', channel = 4)
                sound * 0.5
                sound.play()
        if self.game.events.mouse['up right']:
            if self.MENU:
                self.RESTART = 0
                reset_levels()
                self.MENU = 0
                self.game.current_player = 0
                self.game.restarting = False
                self.game.in_menu = True
                self.game.collected_stars = 0
            if self.RESTART:
                self.RESTART = 0
                reset_levels()
                self.game.players = level_players[self.game.menu_renderer.level_select_renderer.selected_level]
                self.game.players = level_players[self.game.menu_renderer.level_select_renderer.selected_level]
                self.game.Stars = level_stars[self.game.menu_renderer.level_select_renderer.selected_level]
                self.game.map = level_maps[self.game.menu_renderer.level_select_renderer.selected_level]
                self.game.entities = level_mobs[self.game.menu_renderer.level_select_renderer.selected_level]
                self.game.info_bubbles = level_info[self.game.menu_renderer.level_select_renderer.selected_level]
                self.RESTART = 0
                self.game.current_player = 0
                self.game.restarting = False
                self.game.in_menu_sound.stop(500)
                self.game.in_game_sound.play()
                self.game.collected_stars = 0
                self.game.level_start = time.time()


completed_levels = []
completion_times = []
collected_stars  = []
scores           = []
selection_level = pygame.Surface((100, 100))
selection_level.fill((75, 75, 90))

class LevelSelectionScreen:
    def __init__(self, game, buttons: list) -> None:
        self.game = game
        self.screen = self.game.screen
        self.buttons = buttons
        self.PLAY = 0
        self.selected_level = 0
        self.BACK = 0
        self.f = 0
    def render(self) -> None:
        self.f += self.game.time.dt * 2.25
        if self.f >= 2:
            self.f = 0
        self.screen.blit(pygame.transform.scale(self.buttons[self.PLAY]   , (40 * 6, 15 * 6)), [480, 500])
        self.screen.blit(pygame.transform.scale(self.buttons[self.BACK]   , (40 * 4, 15 * 4)), [30, 30])
        Text(self.screen, 'Back', (75, 75, 90), (30 + 20 * 4, 30 + 15 * 4 / 2.70 + self.BACK * 10), 45, True)
        Text(self.screen, 'Select A Level', (75, 75, 90), (600, 40), 60, True)
        Text(self.screen, 'play', (75, 75, 90), (480 + 120, 500 + 15 * 6 / 2.75 + 10 * self.PLAY), 60, True)
        
        i = 0
        for y in range(2):
            for x in range(4):
                if i in completed_levels:
                    pygame.draw.rect(self.screen, (225, 225, 90), [x * 110 + 600 - 110 * 2, y * 110 + 325 - 110, 100, 100])
                    pygame.draw.rect(self.screen, (125, 125, 132), [x * 110 + 600 - 110 * 2 + 3, y * 110 + 325 - 110 + 3, 94, 94])
                else:
                    pygame.draw.rect(self.screen, (75, 75, 90), [x * 110 + 600 - 110 * 2, y * 110 + 325 - 110, 100, 100])
                    pygame.draw.rect(self.screen, (125, 125, 132), [x * 110 + 600 - 110 * 2 + 3, y * 110 + 325 - 110 + 3, 94, 94])
                if i == self.selected_level:
                    self.screen.blit(selection_level, [x * 110 + 600 - 110 * 2, y * 110 + 325 - 110], special_flags = pygame.BLEND_RGB_MULT)
                    if i in completed_levels:
                        ind = completed_levels.index(i)
                        Text(self.screen, 'Score: ' + str(scores[ind]), (75, 75, 90), (400, 140), 60, True)
                        Text(self.screen, 'Time: ' + str(completion_times[ind]), (75, 75, 90), (800, 140), 60, True)
                        for X in range(3):
                            if X < collected_stars[ind]:
                                self.game.screen.blit(pygame.transform.scale(self.game.stars[math.floor(self.f)], (30, 26)), [565 + X * 35, 140 - 13])
                            else:
                                self.game.screen.blit(pygame.transform.scale(self.game.stars[math.floor(self.f) + 2], (30, 26)), [565 + X * 35, 140 - 13])
                    else:
                        Text(self.screen, 'Uncompleted', (75, 75, 90), (600, 140), 50, True)
                Text(self.screen, str(i + 1), (200, 200, 205), (x * 110 + 600 - 110 * 2 + 50, y * 110 + 325 - 110 + 50), 60, True)
                i += 1
        
        mouse_pos = self.game.events.mouse_pos
        if self.game.events.mouse['down right']:
            if Range(mouse_pos[0], 480, 480 + 240) and Range(mouse_pos[1], 500, 500 + 15 * 5):
                self.PLAY = 1
                sound = Sound('sounds/button_clicked.mp3', channel = 4)
                sound * 0.5
                sound.play()
            elif Range(mouse_pos[0], 380, 380 + 440) and Range(mouse_pos[1], 215, 215 + 220):
                self.selected_level = min(math.floor((mouse_pos[0] - 380) / 440 * 4) + math.floor((mouse_pos[1] - 215) / 220 * 2) * 4, 5)
                sound = Sound('sounds/button_clicked.mp3', channel = 4)
                sound * 0.5
                sound.play()
            if Range(mouse_pos[0], 30, 30 + 40 * 4) and Range(mouse_pos[1], 30, 30 + 15 * 4):
                self.BACK = 1
                sound = Sound('sounds/button_clicked.mp3', channel = 4)
                sound * 0.5
                sound.play()
        if self.game.events.mouse['up right']:
            if self.PLAY:
                self.game.players = level_players[self.selected_level]
                self.game.Stars = level_stars[self.selected_level]
                self.game.map = level_maps[self.selected_level]
                self.game.entities = level_mobs[self.selected_level]
                self.game.info_bubbles = level_info[self.selected_level]
                self.game.menu_renderer.selecting = False
                self.PLAY = 0
                self.game.in_menu = False
                self.game.level_start = time.time()
                self.game.collected_stars = 0
                self.game.in_menu_sound.stop(1000)
                self.game.in_game_sound.start = time.time()
                self.game.in_game_sound.play()
            if self.BACK:
                self.BACK = 0
                self.game.menu_renderer.selecting = False


mob1_surf = pygame.Surface((20, 20))
mob1_surf.fill((0, 0, 0))

class Game:
    def __init__(self) -> None:
        self.players = None
        self.Stars = None
        self.current_player = 0
        self.time = Time()
        self.events = Events(self)
        self.res = (1200, 750)
        self.screen = pygame.Surface((1200, 750))
        self.Rscreen = pygame.display.set_mode(self.res)
        pygame.display.set_caption('ScoreSpace #12')
        self.map = None
        self.running = True
        self.camera_pos = (600, 375)

        self.in_menu = True
        self.menu_renderer = Menu(self)
        
        self.current_playing = 0
        self.in_game_sound = Sound('in_game_music.mp3', channel = 2, fade_ms = 1000, volume = 1, loops = -1)
        self.in_game_sound2 = Sound('in_game_spotted.mp3', channel = 4, fade_ms = 1000, volume = 1, loops = -1)
        self.song_switch = time.time()
        self.in_game_sound2 * 2.5
        self.in_menu_sound = Sound('menu_music.mp3', channel = 1, loops = -1, volume = 1, fade_ms = 1000)
        self.in_game_sound * 0.75
        self.in_menu_sound * 0.75
        self.in_menu_sound.play()

        self.restart_screen = RestartScreenRenderer(self)
        self.restarting = False

        self.collected_stars = -1
        self.level_start = -1
        self.level_end = -1
        self.won = False
        self.won_renderer = WonScreenRenderer(self)

        self.entities = None

        self.stars = Spritesheet('stars.png').get_images(15, 13)

        self.info_bubbles = []
    def update(self) -> None:
        self.time.start()
        self.events.update()
        if not self.running:
            return None

        if not self.in_menu and not self.restarting and not self.won:
            try:
                if self.events.down['1']:
                    self.players[0]
                    self.current_player = 0
                elif self.events.down['2']:
                    self.players[1]
                    self.current_player = 1
                elif self.events.down['3']:
                    self.players[2]
                    self.current_player = 2
                elif self.events.down['4']:
                    self.players[3]
                    self.current_player = 3
            except IndexError:
                pass
            
            for player in self.players:
                player.update_without_move()
            player = self.players[self.current_player]
            player.update()
            dif = (player.pos[0] - self.camera_pos[0], player.pos[1] - self.camera_pos[1])
            self.camera_pos = ((self.camera_pos[0] + dif[0] / 20) - 18.75, (self.camera_pos[1] + dif[1] / 20) - 30)

            spotted = False
            for ent in self.entities:
                ent.update()
                spotted = spotted or ent.state.split(' ')[0] in ['mad', 'shooting']
            
            if spotted and not self.current_playing and time.time() - self.song_switch > 1.25:
                self.current_playing = 1
                self.in_game_sound.stop(1000)
                self.in_game_sound2.play()
                self.song_switch = time.time()
            elif not spotted and self.current_playing and time.time() - self.song_switch > 1.25:
                self.current_playing = 0
                self.in_game_sound2.stop(1000)
                self.in_game_sound.play()
                self.song_switch = time.time()
            
            self.restarting = True
            for player in self.players:
                self.restarting = self.restarting and not player.alive
            for star in self.Stars:
                star.update()
            if self.events.down['esc']:
                self.restarting = True
                reset_levels()
            if self.restarting:
                self.in_game_sound.stop(500)
                self.in_menu_sound.play()
                sound = Sound('sounds/game_over.mp3', channel = 5)
                sound * 0.5
                sound.play()
        
        self.screen.fill((225, 225, 225))

        if self.in_menu or self.restarting or self.won:
            if self.in_menu:
                self.menu_renderer.render()
            elif self.restarting or self.won:
                self.map.render()
                for bubble in self.info_bubbles:
                    bubble.render()
                for ent in self.entities:
                    ent.render()
                for player in self.players:
                    player.render()
                self.map.render_lights()
                if self.restarting:
                    self.restart_screen.render()
                else:
                    self.won_renderer.render()
        else:
            self.map.render()

            for bubble in self.info_bubbles:
                bubble.render()

            for ent in self.entities:
                ent.render()
            
            for star in self.Stars:
                star.render()

            for player in self.players:
                player.render()

            """
            i = 0
            for tile in self.map.tiles:
                self.screen.blit(tile, [(5 * 6 - i) * 48 + 400, 0])#[(i % 6) * 48, (i // 6) * 48])
                i += 1
            #"""

            self.map.render_lights()

        Text(self.screen, 'FPS:' + str(round(self.time.fps, 2)), (0, 0, 0), (10, 10), 35)

        self.Rscreen.blit(pygame.transform.scale(self.screen, self.res), [0, 0])
        pygame.display.update()
        self.time.end()


class InfoBubble:
    def __init__(self, game, pos: tuple, text: str, size: tuple) -> None:
        self.game = game
        self.pos = pos
        self.text = text
        self.size = size
        self.bubble = pygame.transform.scale(pygame.image.load('info_bubble.png'), self.size)
    def render(self) -> None:
        n_pos = (self.pos[1] - self.game.camera_pos[1], self.pos[0] - self.game.camera_pos[0])
        if Range(n_pos[0], -500, 1200) and Range(n_pos[1], -500, 750):
            self.game.screen.blit(self.bubble, n_pos)
            Text(self.game.screen, self.text, (75, 75, 90), (n_pos[0] + self.size[0] // 2, n_pos[1] + self.size[1] // 2), 25, True)


def reset_levels() -> None:
    global level_mobs, level_maps, level_players, level_stars, level_info
    level_maps    = [Map(game, 'map0.map', 'tiles.png', 2, animation_links = {"35": {"tiles": [30, 31, 32, 33, 34, 35, 35, 35], "speed": 6}, "36": {"tiles": [36, 37], "speed": 2}, "38": {"tiles": [38, 39], "speed": 2}, "41": {"tiles": [41, 42, 43], "speed": 2}}), Map(game, 'map1.map', 'tiles.png', 2, animation_links = {"35": {"tiles": [30, 31, 32, 33, 34, 35, 35, 35], "speed": 6}, "36": {"tiles": [36, 37], "speed": 2}, "38": {"tiles": [38, 39], "speed": 2}, "41": {"tiles": [41, 42, 43], "speed": 2}}), Map(game, 'map3.map', 'tiles.png', 2, animation_links = {"35": {"tiles": [30, 31, 32, 33, 34, 35, 35, 35], "speed": 6}, "36": {"tiles": [36, 37], "speed": 2}, "38": {"tiles": [38, 39], "speed": 2}, "41": {"tiles": [41, 42, 43], "speed": 2}}), Map(game, 'map.map', 'tiles.png', 2, animation_links = {"35": {"tiles": [30, 31, 32, 33, 34, 35, 35, 35], "speed": 6}, "36": {"tiles": [36, 37], "speed": 2}, "38": {"tiles": [38, 39], "speed": 2}, "41": {"tiles": [41, 42, 43], "speed": 2}}), Map(game, 'map5.map', 'tiles.png', 2, animation_links = {"35": {"tiles": [30, 31, 32, 33, 34, 35, 35, 35], "speed": 6}, "36": {"tiles": [36, 37], "speed": 2}, "38": {"tiles": [38, 39], "speed": 2}, "41": {"tiles": [41, 42, 43], "speed": 2}}), Map(game, 'map6.map', 'tiles.png', 2, animation_links = {"35": {"tiles": [30, 31, 32, 33, 34, 35, 35, 35], "speed": 6}, "36": {"tiles": [36, 37], "speed": 2}, "38": {"tiles": [38, 39], "speed": 2}, "41": {"tiles": [41, 42, 43], "speed": 2}}), Map(game, 'map7.map', 'tiles.png', 2, animation_links = {"35": {"tiles": [30, 31, 32, 33, 34, 35, 35, 35], "speed": 6}, "36": {"tiles": [36, 37], "speed": 2}, "38": {"tiles": [38, 39], "speed": 2}, "41": {"tiles": [41, 42, 43], "speed": 2}}), Map(game, 'map8.map', 'tiles.png', 2, animation_links = {"35": {"tiles": [30, 31, 32, 33, 34, 35, 35, 35], "speed": 6}, "36": {"tiles": [36, 37], "speed": 2}, "38": {"tiles": [38, 39], "speed": 2}, "41": {"tiles": [41, 42, 43], "speed": 2}})]
    level_stars   = [[Star(game, (1000, 1144)), Star(game, (1400, 1250)), Star(game, (1400, 460))], [Star(game, (1000, 1144)), Star(game, (1000, 450)), Star(game, (1400, 1250))]        , [Star(game, (1000, 1144)), Star(game, (1155, 750)), Star(game, (1400, 1250))]                                                            , [Star(game, (1000, 1144)), Star(game, (1000, 450)), Star(game, (1400, 1250))]                                                                                                                , [Star(game, (910, 875)), Star(game, (1400, 1250)), Star(game, (800, 1050))], [Star(game, (1220, 920)), Star(game, (1400, 1250)), Star(game, (1000, 460))], [], []]
    level_players = [[Player(game, pos = (1400, 800))]                                            , [Player(game, pos = (1400, 800)), Player(game, pos = (1400, 700), ability = 'mario')], [Player(game, pos = (1400, 800)), Player(game, pos = (1400, 700), ability = 'mario'), Player(game, pos = (1400, 850), ability = 'phase')], [Player(game, pos = (1400, 700)), Player(game, pos = (1400, 750), ability = 'mario'), Player(game, pos = (1400, 800), ability = 'phase'), Player(game, pos = (1400, 850), ability = 'kirby')], [Player(game, pos = (1400, 700)), Player(game, pos = (1400, 750), ability = 'mario'), Player(game, pos = (1400, 800), ability = 'phase'), Player(game, pos = (1400, 850), ability = 'kirby')], [Player(game, pos = (1400, 700)), Player(game, pos = (1400, 750), ability = 'mario'), Player(game, pos = (1400, 800), ability = 'phase'), Player(game, pos = (1400, 850), ability = 'kirby')], [Player(game, pos = (1400, 700)), Player(game, pos = (1400, 750), ability = 'mario'), Player(game, pos = (1400, 800), ability = 'phase'), Player(game, pos = (1400, 850), ability = 'kirby')], [Player(game, pos = (1400, 700)), Player(game, pos = (1400, 750), ability = 'mario'), Player(game, pos = (1400, 800), ability = 'phase'), Player(game, pos = (1400, 850), ability = 'kirby')]]
    level_mobs    = [[Entity(game, (1000, 1200)), Entity(game, (750, 1000))]                      , [Entity(game, (1000, 1200)), Entity(game, (750, 1000))]                              , [Entity(game, (750, 1175))]                                                                                                              , [Entity(game, (1000, 1200)), Entity(game, (750, 1000))]                                                                                                                                      , [Entity(game, (1175, 850))]                                                , [Entity(game, (850, 1400)), Entity(game, (1000, 1400)), Entity(game, (1400, 1400)), Entity(game, (1250, 1400))], [], []]
    level_info    = [[InfoBubble(game, (1400, 700), 'Right Click To Pick Up Blocks', (300, 50)), InfoBubble(game, (1400, 1050), 'Left Click To Place', (300, 50))], [InfoBubble(game, (1400, 700), 'Use The Number Keys To Change Character', (375, 70)), InfoBubble(game, (1200, 1300), 'Tower Up', (100, 35)), InfoBubble(game, (1050, 600), 'Player 2 Can Bounce Of Mobs', (350, 50))], [InfoBubble(game, (1400, 550), 'Place A Block On A Block To Combine Them', (450, 70)), InfoBubble(game, (1400, 1050), 'Player 3 Can Go Trough Gas', (250, 70)), InfoBubble(game, (1250, 700), 'Steal Blocks Bullets', (250, 70))], [InfoBubble(game, (1250, 700), 'You Can Kill Mob by Jumping On Them With Player 4', (500, 80))], [], [], [], []]

    level_mobs[1][1].alive = False


game = Game()

w = open('map.map').read()
newData = ''
i = 0
lw = list(w)
for l in lw:
    """
    if l == '3':
        try:
            if lw[i - 1] in [',', ' ', '|', '\\', 'n'] and lw[i + 1] in [',', ' ', '|', '\\', 'n']:
                newData += str([1, 2, 3, 3, 3, 35][random.randint(0, 5)])
            else:
                newData += l
        except IndexError:
            newData += l
    else:
        newData += l
    """
    """
    try:
        if l + lw[i + 1] == '28':
            try:
                if lw[i - 1] in [',', ' ', '|', '\\', 'n'] and lw[i + 2] in [',', ' ', '|', '\\', 'n']:
                    newData += str([28, 29][random.randint(0, 1)])
                else:
                    newData += l
            except IndexError:
                newData += l
        else:
            newData += l
    except IndexError:
        newData += l
    """
    newData += l
    i += 1
with open('map.map', 'w') as out:
    out.write(newData)

reset_levels()

level_maps    = [Map(game, 'map0.map', 'tiles.png', 2, animation_links = {"35": {"tiles": [30, 31, 32, 33, 34, 35, 35, 35], "speed": 6}, "36": {"tiles": [36, 37], "speed": 2}, "38": {"tiles": [38, 39], "speed": 2}, "41": {"tiles": [41, 42, 43], "speed": 2}}), Map(game, 'map1.map', 'tiles.png', 2, animation_links = {"35": {"tiles": [30, 31, 32, 33, 34, 35, 35, 35], "speed": 6}, "36": {"tiles": [36, 37], "speed": 2}, "38": {"tiles": [38, 39], "speed": 2}, "41": {"tiles": [41, 42, 43], "speed": 2}}), Map(game, 'map3.map', 'tiles.png', 2, animation_links = {"35": {"tiles": [30, 31, 32, 33, 34, 35, 35, 35], "speed": 6}, "36": {"tiles": [36, 37], "speed": 2}, "38": {"tiles": [38, 39], "speed": 2}, "41": {"tiles": [41, 42, 43], "speed": 2}}), Map(game, 'map.map', 'tiles.png', 2, animation_links = {"35": {"tiles": [30, 31, 32, 33, 34, 35, 35, 35], "speed": 6}, "36": {"tiles": [36, 37], "speed": 2}, "38": {"tiles": [38, 39], "speed": 2}, "41": {"tiles": [41, 42, 43], "speed": 2}}), Map(game, 'map5.map', 'tiles.png', 2, animation_links = {"35": {"tiles": [30, 31, 32, 33, 34, 35, 35, 35], "speed": 6}, "36": {"tiles": [36, 37], "speed": 2}, "38": {"tiles": [38, 39], "speed": 2}, "41": {"tiles": [41, 42, 43], "speed": 2}}), Map(game, 'map6.map', 'tiles.png', 2, animation_links = {"35": {"tiles": [30, 31, 32, 33, 34, 35, 35, 35], "speed": 6}, "36": {"tiles": [36, 37], "speed": 2}, "38": {"tiles": [38, 39], "speed": 2}, "41": {"tiles": [41, 42, 43], "speed": 2}}), Map(game, 'map7.map', 'tiles.png', 2, animation_links = {"35": {"tiles": [30, 31, 32, 33, 34, 35, 35, 35], "speed": 6}, "36": {"tiles": [36, 37], "speed": 2}, "38": {"tiles": [38, 39], "speed": 2}, "41": {"tiles": [41, 42, 43], "speed": 2}}), Map(game, 'map8.map', 'tiles.png', 2, animation_links = {"35": {"tiles": [30, 31, 32, 33, 34, 35, 35, 35], "speed": 6}, "36": {"tiles": [36, 37], "speed": 2}, "38": {"tiles": [38, 39], "speed": 2}, "41": {"tiles": [41, 42, 43], "speed": 2}})]
level_stars   = [[Star(game, (1000, 1144)), Star(game, (1400, 1250)), Star(game, (1400, 460))], [Star(game, (1000, 1144)), Star(game, (1000, 450)), Star(game, (1400, 1250))]        , [Star(game, (1000, 1144)), Star(game, (1155, 750)), Star(game, (1400, 1250))]                                                            , [Star(game, (1000, 1144)), Star(game, (1000, 450)), Star(game, (1400, 1250))]                                                                                                                , [Star(game, (910, 875)), Star(game, (1400, 1250)), Star(game, (800, 1050))], [Star(game, (1220, 920)), Star(game, (1400, 1250)), Star(game, (1000, 460))], [], []]
level_players = [[Player(game, pos = (1400, 800))]                                            , [Player(game, pos = (1400, 800)), Player(game, pos = (1400, 700), ability = 'mario')], [Player(game, pos = (1400, 800)), Player(game, pos = (1400, 700), ability = 'mario'), Player(game, pos = (1400, 850), ability = 'phase')], [Player(game, pos = (1400, 700)), Player(game, pos = (1400, 750), ability = 'mario'), Player(game, pos = (1400, 800), ability = 'phase'), Player(game, pos = (1400, 850), ability = 'kirby')], [Player(game, pos = (1400, 700)), Player(game, pos = (1400, 750), ability = 'mario'), Player(game, pos = (1400, 800), ability = 'phase'), Player(game, pos = (1400, 850), ability = 'kirby')], [Player(game, pos = (1400, 700)), Player(game, pos = (1400, 750), ability = 'mario'), Player(game, pos = (1400, 800), ability = 'phase'), Player(game, pos = (1400, 850), ability = 'kirby')], [Player(game, pos = (1400, 700)), Player(game, pos = (1400, 750), ability = 'mario'), Player(game, pos = (1400, 800), ability = 'phase'), Player(game, pos = (1400, 850), ability = 'kirby')], [Player(game, pos = (1400, 700)), Player(game, pos = (1400, 750), ability = 'mario'), Player(game, pos = (1400, 800), ability = 'phase'), Player(game, pos = (1400, 850), ability = 'kirby')]]
level_mobs    = [[Entity(game, (1000, 1200)), Entity(game, (750, 1000))]                      , [Entity(game, (1000, 1200)), Entity(game, (750, 1000))]                              , [Entity(game, (750, 1175))]                                                                                                              , [Entity(game, (1000, 1200)), Entity(game, (750, 1000))]                                                                                                                                      , [Entity(game, (1175, 850))]                                                , [Entity(game, (850, 1400)), Entity(game, (1000, 1400)), Entity(game, (1400, 1400)), Entity(game, (1250, 1400))], [], []]
level_info    = [[InfoBubble(game, (1400, 700), 'Right Click To Pick Up Blocks', (300, 50)), InfoBubble(game, (1400, 1050), 'Left Click To Place', (300, 50))], [InfoBubble(game, (1400, 700), 'Use The Number Keys To Change Character', (375, 70)), InfoBubble(game, (1200, 1300), 'Tower Up', (100, 35)), InfoBubble(game, (1050, 600), 'Player 2 Can Bounce Of Mobs', (350, 50))], [InfoBubble(game, (1400, 550), 'Place A Block On A Block To Combine Them', (450, 70)), InfoBubble(game, (1400, 1050), 'Player 3 Can Go Trough Gas', (250, 70)), InfoBubble(game, (1250, 700), 'Steal Blocks Bullets', (250, 70))], [InfoBubble(game, (1250, 700), 'You Can Kill Mob by Jumping On Them With Player 4', (500, 80))], [], [], [], []]

level_mobs[1][1].alive = False

while game.running:
    game.update()

